Contains HTML of Dylan library doc, 1st draft.
